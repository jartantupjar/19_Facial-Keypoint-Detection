You may find the saved_model in my gdrive. Could not submit it directly as the weights are 750 mb  
 
https://drive.google.com/file/d/1w5Dg7rsgNSgcF4gOCEeejY7YOItnRjxg/view?usp=sharing