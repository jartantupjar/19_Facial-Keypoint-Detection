You may find the saved_model in my gdrive. Could not submit it directly as the weights are 750 mb  
 
https://drive.google.com/drive/folders/1MYI_PxhrburCKYimuZ7MkxFkFI0wmMqt?usp=sharing